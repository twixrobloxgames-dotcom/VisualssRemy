package dev.remy.visuals.gui;

import dev.remy.visuals.module.Category;
import dev.remy.visuals.module.Module;
import dev.remy.visuals.module.Modules;
import dev.remy.visuals.module.Setting;
import dev.remy.visuals.util.Config;
import dev.remy.visuals.util.Draw;
import dev.remy.visuals.util.Theme;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class ClickGui extends Screen {
    static final int W = 440, H = 280;
    Category cur = Category.VISUALS;
    Module selected; // открыта страница настроек этого модуля

    public ClickGui() { super(Text.literal("RemyVisuals")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); }

    int x0() { return (width - W) / 2; }
    int y0() { return (height - H) / 2; }
    List<Module> mods() { return Modules.ALL.stream().filter(m -> m.cat == cur).toList(); }

    int[] card(int i) {
        int cw = (W - 126 - 8) / 2;
        return new int[]{x0() + 118 + (i % 2) * (cw + 8), y0() + 34 + (i / 2) * 31, cw, 27};
    }
    int[] tab(int i) { return new int[]{x0() + 12, y0() + 80 + i * 26, 92, 22}; }
    int[] dot(int i) { return new int[]{x0() + 124 + i * 22, y0() + H - 18}; }
    int[] back() { return new int[]{x0() + 118, y0() + 34, 54, 18}; }
    int[] row(int i) { return new int[]{x0() + 118, y0() + 62 + i * 30, W - 126, 26}; }

    static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0x66000000);
        int x0 = x0(), y0 = y0(), col = Theme.color();

        Draw.rrect(c, x0 - 1, y0 - 1, W + 2, H + 2, 9, Theme.alpha(col, 140));
        Draw.rrect(c, x0, y0, W, H, 8, 0xF00F0F13);
        Draw.rrect(c, x0 + 6, y0 + 6, 104, H - 12, 6, 0xFF16161B);
        Draw.avatar(c, x0 + 58, y0 + 34, 17);
        c.drawCenteredTextWithShadow(textRenderer, "Remy", x0 + 40, y0 + 58, col);
        c.drawCenteredTextWithShadow(textRenderer, "Visuals", x0 + 76, y0 + 58, 0xFFFFFFFF);

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int[] t = tab(i);
            boolean sel = cats[i] == cur, hov = in(mx, my, t[0], t[1], t[2], t[3]);
            if (sel) {
                Draw.rrect(c, t[0], t[1], t[2], t[3], 5, Theme.alpha(col, 70));
                Draw.rrect(c, t[0], t[1] + 4, 2, t[3] - 8, 1, col);
            } else if (hov) Draw.rrect(c, t[0], t[1], t[2], t[3], 5, 0x33FFFFFF);
            c.drawText(textRenderer, cats[i].label, t[0] + 12, t[1] + 7, sel ? 0xFFFFFFFF : 0xFFA0A0AA, true);
        }
        c.drawCenteredTextWithShadow(textRenderer, "RShift - menu", x0 + 58, y0 + H - 20, 0xFF606068);

        c.drawText(textRenderer, selected == null ? cur.label : selected.name, x0 + 118, y0 + 14, 0xFFFFFFFF, true);
        c.fill(x0 + 118, y0 + 27, x0 + W - 8, y0 + 28, Theme.alpha(col, 120));

        if (selected == null) renderModules(c, mx, my); else renderSettings(c, mx, my);

        c.drawText(textRenderer, "Color", x0 + 118, y0 + H - 38, 0xFFA0A0AA, true);
        for (int i = 0; i < Theme.NAMES.length; i++) {
            int[] d = dot(i);
            int cc = i < Theme.COLORS.length ? Theme.COLORS[i] : Theme.rainbow(0);
            if (i == Theme.index) Draw.circle(c, d[0], d[1], 9, 0xFFFFFFFF, 0xFFFFFFFF);
            Draw.circle(c, d[0], d[1], 7, cc, Theme.darker(cc, 0.6f));
        }
        String tn = Theme.NAMES[Theme.index];
        c.drawText(textRenderer, tn, x0 + W - 12 - textRenderer.getWidth(tn), y0 + H - 38, Theme.color(), true);
    }

    void renderModules(DrawContext c, int mx, int my) {
        int col = Theme.color();
        List<Module> list = mods();
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int[] r = card(i);
            boolean hov = in(mx, my, r[0], r[1], r[2], r[3]);
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;
            Draw.rrect(c, r[0], r[1], r[2], r[3], 6, hov ? 0xFF22222A : 0xFF1A1A20);
            if (m.anim > 0.02f) Draw.rrect(c, r[0], r[1], r[2], r[3], 6, Theme.alpha(col, (int) (55 * m.anim)));
            c.drawText(textRenderer, m.name, r[0] + 7, r[1] + 5, 0xFFFFFFFF, true);
            c.drawText(textRenderer, m.desc, r[0] + 7, r[1] + 16, 0xFF808088, false);
            int sx = r[0] + r[2] - 28, sy = r[1] + 4;
            Draw.rrect(c, sx, sy, 22, 10, 5, Theme.lerp(0xFF33333B, col, m.anim));
            Draw.rrect(c, sx + 2 + (int) (12 * m.anim), sy + 2, 6, 6, 3, 0xFFFFFFFF);
            if (!m.settings.isEmpty()) // три точки = есть настройки (ПКМ)
                for (int d = 0; d < 3; d++) c.fill(sx + 5 + d * 4, sy + 14, sx + 7 + d * 4, sy + 16, 0xFF9A9AA4);
        }
    }

    void renderSettings(DrawContext c, int mx, int my) {
        int col = Theme.color();
        int[] b = back();
        Draw.rrect(c, b[0], b[1], b[2], b[3], 5, in(mx, my, b[0], b[1], b[2], b[3]) ? 0xFF2A2A33 : 0xFF1C1C22);
        c.drawCenteredTextWithShadow(textRenderer, "< Back", b[0] + b[2] / 2, b[1] + 5, 0xFFFFFFFF);
        for (int i = 0; i < selected.settings.size(); i++) {
            Setting s = selected.settings.get(i);
            int[] r = row(i);
            Draw.rrect(c, r[0], r[1], r[2], r[3], 5, 0xFF1A1A20);
            c.drawText(textRenderer, s.name, r[0] + 8, r[1] + 5, 0xFFFFFFFF, true);
            String v = s.isMode() ? "< " + s.display() + " >" : s.display();
            c.drawText(textRenderer, v, r[0] + r[2] - 8 - textRenderer.getWidth(v), r[1] + 5, col, true);
            if (!s.isMode()) {
                int tx = r[0] + 8, tw = r[2] - 16, ty = r[1] + 18;
                Draw.rrect(c, tx, ty, tw, 4, 2, 0xFF33333B);
                float f = (float) ((s.value - s.min) / (s.max - s.min));
                Draw.rrect(c, tx, ty, Math.max(4, (int) (tw * f)), 4, 2, col);
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        if (btn != 0 && btn != 1) return super.mouseClicked(click, doubled);

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int[] t = tab(i);
            if (in(mx, my, t[0], t[1], t[2], t[3])) { cur = cats[i]; selected = null; return true; }
        }
        for (int i = 0; i < Theme.NAMES.length; i++) {
            int[] d = dot(i);
            if (Math.hypot(mx - d[0], my - d[1]) <= 9) { Theme.index = i; return true; }
        }
        if (selected == null) {
            List<Module> list = mods();
            for (int i = 0; i < list.size(); i++) {
                int[] r = card(i);
                if (in(mx, my, r[0], r[1], r[2], r[3])) {
                    if (btn == 0) list.get(i).toggle();
                    else if (!list.get(i).settings.isEmpty()) selected = list.get(i);
                    return true;
                }
            }
        } else {
            int[] b = back();
            if (in(mx, my, b[0], b[1], b[2], b[3])) { selected = null; return true; }
            for (int i = 0; i < selected.settings.size(); i++) {
                int[] r = row(i);
                if (!in(mx, my, r[0], r[1], r[2], r[3])) continue;
                Setting s = selected.settings.get(i);
                if (s.isMode()) s.value = (s.mode() + 1) % s.modes.length;
                else {
                    double f = Math.max(0, Math.min(1, (mx - (r[0] + 8)) / (double) (r[2] - 16)));
                    s.value = Math.round((s.min + f * (s.max - s.min)) * 20) / 20.0;
                }
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }
}
