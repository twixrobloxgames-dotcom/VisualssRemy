package dev.remy.visuals.util;

import java.awt.Color;

public final class Theme {
    public static final String[] NAMES = {"Purple", "Blue", "Red", "Green", "Orange", "Pink", "Cyan", "Rainbow"};
    public static final int[] COLORS = {0xFF9B5CFF, 0xFF4C8DFF, 0xFFFF4C5E, 0xFF4CFF8A, 0xFFFFA84C, 0xFFFF6EC7, 0xFF4CE6FF};
    public static int index = 0;

    public static int color() {
        if (index >= COLORS.length) return rainbow(0);
        return COLORS[index];
    }

    public static int rainbow(int offset) {
        float h = ((System.currentTimeMillis() + offset) % 4000L) / 4000f;
        return Color.HSBtoRGB(h, 0.65f, 1f) | 0xFF000000;
    }

    public static int alpha(int c, int a) { return (a << 24) | (c & 0xFFFFFF); }

    public static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int darker(int c, float f) { return lerp(c, 0xFF000000, 1 - f); }
}
