package dev.remy.visuals.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

public final class Draw {
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int in = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + in, y + i, x + w - in, y + i + 1, col);
            c.fill(x + in, y + h - i - 1, x + w - in, y + h - i, col);
        }
        c.fill(x, y + r, x + w, y + h - r, col);
    }

    /** Тёмная плашка HUD с цветной линией снизу. */
    public static void panel(DrawContext c, int x, int y, int w, int h) {
        rrect(c, x, y, w, h, 4, 0xC0101014);
        c.fill(x + 4, y + h - 1, x + w - 4, y + h, Theme.color());
    }

    public static void circle(DrawContext c, int cx, int cy, int r, int top, int bottom) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.sqrt(r * r - dy * dy);
            float t = (dy + r) / (2f * r);
            c.fill(cx - w, cy + dy, cx + w, cy + dy + 1, Theme.lerp(top, bottom, t));
        }
    }

    /** Аватарка RemyVisuals: круг в цвет темы с буквой R. */
    public static void avatar(DrawContext c, int cx, int cy, int r) {
        int col = Theme.color();
        circle(c, cx, cy, r + 1, 0x55FFFFFF, 0x22FFFFFF);
        circle(c, cx, cy, r, col, Theme.darker(col, 0.55f));
        Matrix3x2fStack m = c.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        float s = r / 6.5f;
        m.scale(s, s);
        c.drawText(MinecraftClient.getInstance().textRenderer, "R", -3, -4, 0xFFFFFFFF, true);
        m.popMatrix();
    }

    public static int tw(String s) { return MinecraftClient.getInstance().textRenderer.getWidth(s); }
}
