package dev.remy.visuals.util;

import dev.remy.visuals.module.Module;
import dev.remy.visuals.module.Modules;
import dev.remy.visuals.module.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("remyvisuals.properties"); }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("theme", String.valueOf(Theme.index));
        for (Module m : Modules.ALL) {
            p.setProperty(m.name + ".on", String.valueOf(m.enabled));
            for (Setting s : m.settings) p.setProperty(m.name + "." + s.name, String.valueOf(s.value));
        }
        try (Writer w = Files.newBufferedWriter(file())) { p.store(w, "RemyVisuals"); } catch (IOException ignored) {}
    }

    public static void load() {
        if (!Files.exists(file())) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(file())) { p.load(r); } catch (IOException e) { return; }
        try {
            Theme.index = Math.max(0, Math.min(Theme.NAMES.length - 1, Integer.parseInt(p.getProperty("theme", "0"))));
            for (Module m : Modules.ALL) {
                String on = p.getProperty(m.name + ".on");
                if (on != null) m.enabled = Boolean.parseBoolean(on);
                for (Setting s : m.settings) {
                    String v = p.getProperty(m.name + "." + s.name);
                    if (v != null) s.value = Math.max(s.min, Math.min(s.max, Double.parseDouble(v)));
                }
            }
        } catch (NumberFormatException ignored) {}
    }
}
