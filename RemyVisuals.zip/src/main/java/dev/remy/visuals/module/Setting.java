package dev.remy.visuals.module;

public class Setting {
    public final String name;
    public double value;
    public final double min, max;
    public final String[] modes;

    public Setting(String name, double min, double max, double value) {
        this.name = name; this.min = min; this.max = max; this.value = value; this.modes = null;
    }

    public Setting(String name, int index, String... modes) {
        this.name = name; this.min = 0; this.max = modes.length - 1; this.value = index; this.modes = modes;
    }

    public boolean isMode() { return modes != null; }
    public float f() { return (float) value; }
    public int mode() { return (int) value; }

    public String display() {
        if (isMode()) return modes[(int) value];
        if (Math.abs(value - Math.round(value)) < 1e-6) return String.valueOf(Math.round(value));
        return String.format("%.2f", value);
    }
}
