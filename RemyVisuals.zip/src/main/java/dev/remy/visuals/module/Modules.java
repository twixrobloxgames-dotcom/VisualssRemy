package dev.remy.visuals.module;

import dev.remy.visuals.util.Draw;
import dev.remy.visuals.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();
    public static Fullbright fullbright;
    public static SwingAnimation swing;
    public static ViewModel viewModel;
    public static Zoom zoom;
    public static HitEffect hit;

    public static void init() {
        fullbright = new Fullbright();
        swing = new SwingAnimation();
        viewModel = new ViewModel();
        zoom = new Zoom();
        hit = new HitEffect();
        // Visuals
        ALL.add(swing);
        ALL.add(viewModel);
        ALL.add(new JumpCircles());
        ALL.add(hit);
        ALL.add(new ChinaHat());
        ALL.add(new Trails());
        ALL.add(fullbright);
        ALL.add(zoom);
        ALL.add(new GlowEsp());
        ALL.add(new Radar());
        ALL.add(new TargetHud());
        ALL.add(new ArmorHud());
        ALL.add(new Keystrokes());
        ALL.add(new Coordinates());
        ALL.add(new Fps());
        // Interface
        ALL.add(new Watermark());
        ALL.add(new Potions());
        ALL.add(new BetterNear());
        ALL.add(new ArrayListHud());
    }

    static List<PlayerEntity> others(MinecraftClient mc, double range) {
        List<PlayerEntity> l = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers())
            if (p != mc.player && mc.player.distanceTo(p) <= range) l.add(p);
        l.sort(Comparator.comparingDouble(mc.player::distanceTo));
        return l;
    }

    static DustParticleEffect dust(float scale) {
        return new DustParticleEffect(Theme.color() & 0xFFFFFF, scale);
    }

    // ───────────────────────── VISUALS ─────────────────────────

    public static class SwingAnimation extends Module {
        final Setting style = mode("Style", 0, "Slash", "Spin", "Down", "Smooth");
        final Setting strength = num("Strength", 0.5, 2.0, 1.0);

        SwingAnimation() { super("Swing Animation", "Анимация удара рукой", Category.VISUALS); }

        public void apply(MatrixStack m, Arm arm, float sp) {
            if (!enabled || sp <= 0f) return;
            float i = arm == Arm.RIGHT ? 1f : -1f, k = strength.f();
            float s = (float) Math.sin(sp * Math.PI);
            switch (style.mode()) {
                case 0 -> { // Slash
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-50f * s * i * k));
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-40f * s * k));
                }
                case 1 -> { // Spin
                    m.translate(0f, 0f, -0.2f * s);
                    m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(360f * sp * k * i));
                }
                case 2 -> { // Down
                    m.translate(0f, -0.45f * s * k, 0f);
                    m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(70f * s * k));
                }
                default -> { // Smooth
                    m.translate(0.2f * i * s * k, -0.12f * s, -0.35f * s * k);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(20f * s * i * k));
                }
            }
        }
    }

    public static class ViewModel extends Module {
        final Setting x = num("X", -1.0, 1.0, 0.0);
        final Setting y = num("Y", -1.0, 1.0, 0.0);
        final Setting z = num("Z", -1.0, 1.0, 0.0);
        final Setting scale = num("Scale", 0.3, 1.5, 1.0);

        ViewModel() { super("View Model", "Позиция и размер рук", Category.VISUALS); }

        public void apply(MatrixStack m, Arm arm) {
            if (!enabled) return;
            float i = arm == Arm.RIGHT ? 1f : -1f;
            m.translate(x.f() * i, y.f(), z.f());
            float s = scale.f();
            m.scale(s, s, s);
        }
    }

    public static class Zoom extends Module {
        final Setting factor = num("Factor", 1.5, 8.0, 3.0);
        Zoom() { super("Zoom", "Приближение камеры", Category.VISUALS); }
        public float factor() { return enabled ? factor.f() : 1f; }
    }

    static class JumpCircles extends Module {
        final Setting size = num("Size", 0.5, 3.0, 1.5);
        record Ring(double x, double y, double z, int[] age) {}
        final List<Ring> rings = new ArrayList<>();
        boolean wasGround = true;

        JumpCircles() { super("Jump Circles", "Круги при прыжке", Category.VISUALS); }

        public void tick(MinecraftClient mc) {
            boolean ground = mc.player.isOnGround();
            if (wasGround && !ground && mc.player.getVelocity().y > 0.1)
                rings.add(new Ring(mc.player.getX(), mc.player.getY() + 0.03, mc.player.getZ(), new int[]{0}));
            wasGround = ground;
            for (Iterator<Ring> it = rings.iterator(); it.hasNext(); ) {
                Ring r = it.next();
                double radius = 0.3 + r.age[0] * 0.12 * size.value;
                int n = 24;
                for (int i = 0; i < n; i++) {
                    double a = i * Math.PI * 2 / n;
                    mc.world.addParticleClient(dust(1.0f), r.x + Math.cos(a) * radius, r.y, r.z + Math.sin(a) * radius, 0, 0, 0);
                }
                if (++r.age[0] > 12) it.remove();
            }
        }
        public void onDisable(MinecraftClient mc) { rings.clear(); }
    }

    public static class HitEffect extends Module {
        HitEffect() { super("Hit Effect", "Частицы при ударе", Category.VISUALS); }
        public void spawn(Entity e) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null) return;
            double cy = e.getY() + e.getHeight() / 2;
            for (int i = 0; i < 18; i++)
                mc.world.addParticleClient(dust(1.2f), e.getX(), cy, e.getZ(),
                        (Math.random() - 0.5) * 0.4, (Math.random() - 0.3) * 0.4, (Math.random() - 0.5) * 0.4);
        }
    }

    static class ChinaHat extends Module {
        ChinaHat() { super("China Hat", "Шляпа над головой", Category.VISUALS); }
        public void tick(MinecraftClient mc) {
            double top = mc.player.getY() + mc.player.getHeight();
            for (int i = 0; i < 8; i++) {
                double t = Math.random(), a = Math.random() * Math.PI * 2, r = 0.6 * (1 - t);
                mc.world.addParticleClient(dust(0.8f), mc.player.getX() + Math.cos(a) * r, top + 0.05 + 0.3 * t,
                        mc.player.getZ() + Math.sin(a) * r, 0, 0, 0);
            }
        }
    }

    static class Trails extends Module {
        Trails() { super("Trails", "Шлейф в цвет темы", Category.VISUALS); }
        public void tick(MinecraftClient mc) {
            if (mc.player.getVelocity().horizontalLengthSquared() < 0.0005) return;
            for (int i = 0; i < 2; i++)
                mc.world.addParticleClient(dust(1.2f),
                        mc.player.getX() + (Math.random() - 0.5) * 0.4, mc.player.getY() + 0.1 + Math.random() * 0.3,
                        mc.player.getZ() + (Math.random() - 0.5) * 0.4, 0, 0, 0);
        }
    }

    public static class Fullbright extends Module {
        Fullbright() { super("Fullbright", "Полная яркость", Category.VISUALS); }
        public void tick(MinecraftClient mc) {
            StatusEffectInstance e = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (e == null || e.getDuration() < 300)
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600, 0, false, false, false));
        }
        public void onDisable(MinecraftClient mc) { mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); }
    }

    static class GlowEsp extends Module {
        GlowEsp() { super("Glow ESP", "Свечение игроков", Category.VISUALS); }
        public void tick(MinecraftClient mc) {
            for (PlayerEntity p : mc.world.getPlayers()) if (p != mc.player) p.setGlowing(true);
        }
        public void onDisable(MinecraftClient mc) {
            for (PlayerEntity p : mc.world.getPlayers()) p.setGlowing(false);
        }
    }

    static class Radar extends Module {
        Radar() { super("Radar", "Мини-радар игроков", Category.VISUALS); }
        public void hud(DrawContext c, MinecraftClient mc) {
            int r = 32, cx = c.getScaledWindowWidth() - r - 8, cy = c.getScaledWindowHeight() - r - 8;
            Draw.circle(c, cx, cy, r + 1, Theme.alpha(Theme.color(), 200), Theme.alpha(Theme.color(), 90));
            Draw.circle(c, cx, cy, r, 0xE0101014, 0xE0141419);
            c.fill(cx - r, cy, cx + r, cy + 1, 0x33FFFFFF);
            c.fill(cx, cy - r, cx + 1, cy + r, 0x33FFFFFF);
            c.fill(cx - 1, cy - 1, cx + 2, cy + 2, Theme.color());
            double yaw = Math.toRadians(mc.player.getYaw());
            double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
            for (PlayerEntity p : others(mc, 50)) {
                double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
                int sx = cx + (int) ((dx * rx + dz * rz) * (r - 3) / 50.0);
                int sy = cy - (int) ((dx * fx + dz * fz) * (r - 3) / 50.0);
                c.fill(sx - 1, sy - 1, sx + 2, sy + 2, 0xFFFF4C5E);
            }
        }
    }

    static class TargetHud extends Module {
        TargetHud() { super("Target HUD", "Здоровье цели", Category.VISUALS); }
        public void hud(DrawContext c, MinecraftClient mc) {
            if (!(mc.targetedEntity instanceof LivingEntity t)) return;
            int w = 120, h = 32, x = c.getScaledWindowWidth() / 2 + 16, y = c.getScaledWindowHeight() / 2 + 16;
            Draw.panel(c, x, y, w, h);
            c.drawText(mc.textRenderer, t.getName().getString(), x + 6, y + 5, 0xFFFFFFFF, true);
            float hp = Math.max(0, Math.min(1, t.getHealth() / t.getMaxHealth()));
            Draw.rrect(c, x + 6, y + 19, w - 12, 5, 2, 0xFF2A2A32);
            Draw.rrect(c, x + 6, y + 19, Math.max(3, (int) ((w - 12) * hp)), 5, 2, Theme.color());
            String s = String.format("%.1f", t.getHealth());
            c.drawText(mc.textRenderer, s, x + w - 6 - Draw.tw(s), y + 5, 0xFFB0B0B8, false);
        }
    }

    static class ArmorHud extends Module {
        ArmorHud() { super("Armor HUD", "Броня над хотбаром", Category.VISUALS); }
        public void hud(DrawContext c, MinecraftClient mc) {
            int x = c.getScaledWindowWidth() / 2 + 10, y = c.getScaledWindowHeight() - 60;
            Draw.panel(c, x - 3, y - 3, 4 * 18 + 4, 22);
            ItemStack[] armor = {
                    mc.player.getEquippedStack(net.minecraft.entity.EquipmentSlot.HEAD),
                    mc.player.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST),
                    mc.player.getEquippedStack(net.minecraft.entity.EquipmentSlot.LEGS),
                    mc.player.getEquippedStack(net.minecraft.entity.EquipmentSlot.FEET)};
            for (int i = 0; i < 4; i++) {
                c.drawItem(armor[i], x + i * 18, y);
                c.drawStackOverlay(mc.textRenderer, armor[i], x + i * 18, y);
            }
        }
    }

    static class Keystrokes extends Module {
        Keystrokes() { super("Keystrokes", "WASD на экране", Category.VISUALS); }
        void key(DrawContext c, MinecraftClient mc, int x, int y, String l, boolean down) {
            Draw.rrect(c, x, y, 18, 18, 3, down ? Theme.alpha(Theme.color(), 230) : 0xB0101014);
            c.drawCenteredTextWithShadow(mc.textRenderer, l, x + 9, y + 5, 0xFFFFFFFF);
        }
        public void hud(DrawContext c, MinecraftClient mc) {
            int x = 6, y = c.getScaledWindowHeight() / 2 + 20;
            key(c, mc, x + 20, y, "W", mc.options.forwardKey.isPressed());
            key(c, mc, x, y + 20, "A", mc.options.leftKey.isPressed());
            key(c, mc, x + 20, y + 20, "S", mc.options.backKey.isPressed());
            key(c, mc, x + 40, y + 20, "D", mc.options.rightKey.isPressed());
        }
    }

    static class Coordinates extends Module {
        Coordinates() { super("Coordinates", "Координаты", Category.VISUALS); }
        public void hud(DrawContext c, MinecraftClient mc) {
            String s = "XYZ  " + (int) mc.player.getX() + "  " + (int) mc.player.getY() + "  " + (int) mc.player.getZ();
            int w = Draw.tw(s) + 12, y = c.getScaledWindowHeight() - 22;
            Draw.panel(c, 6, y, w, 16);
            c.drawText(mc.textRenderer, s, 12, y + 4, 0xFFFFFFFF, true);
        }
    }

    static class Fps extends Module {
        Fps() { super("FPS", "Счётчик FPS", Category.VISUALS); }
        public void hud(DrawContext c, MinecraftClient mc) {
            String s = mc.getCurrentFps() + " FPS";
            Draw.panel(c, 6, 28, Draw.tw(s) + 12, 16);
            c.drawText(mc.textRenderer, s, 12, 32, 0xFFFFFFFF, true);
        }
    }

    // ───────────────────────── INTERFACE ─────────────────────────

    static class Watermark extends Module {
        Watermark() { super("Watermark", "Ватермарк с аватаркой", Category.INTERFACE); enabled = true; }
        public void hud(DrawContext c, MinecraftClient mc) {
            String tail = "  |  " + mc.player.getName().getString() + "  |  " + mc.getCurrentFps() + " fps";
            int w = 28 + Draw.tw("RemyVisuals") + Draw.tw(tail) + 8;
            Draw.panel(c, 6, 6, w, 18);
            Draw.avatar(c, 16, 15, 6);                       // цвет аватарки = цвет темы
            c.drawText(mc.textRenderer, "Remy", 28, 11, Theme.color(), true);
            c.drawText(mc.textRenderer, "Visuals", 28 + Draw.tw("Remy"), 11, 0xFFFFFFFF, true);
            c.drawText(mc.textRenderer, tail, 28 + Draw.tw("RemyVisuals"), 11, 0xFFB0B0B8, false);
        }
    }

    static class Potions extends Module {
        Potions() { super("Potions", "Список эффектов", Category.INTERFACE); enabled = true; }
        public void hud(DrawContext c, MinecraftClient mc) {
            List<StatusEffectInstance> list = new ArrayList<>();
            for (StatusEffectInstance e : mc.player.getStatusEffects())
                if (!(fullbright.enabled && e.getEffectType() == StatusEffects.NIGHT_VISION)) list.add(e);
            int w = 116, x = 6, y = 50, h = 16 + Math.max(1, list.size()) * 11;
            Draw.panel(c, x, y, w, h);
            c.drawText(mc.textRenderer, "Potions", x + 6, y + 4, Theme.color(), true);
            if (list.isEmpty()) { c.drawText(mc.textRenderer, "нет эффектов", x + 6, y + 16, 0xFF808088, false); return; }
            int row = y + 16;
            for (StatusEffectInstance e : list) {
                String n = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
                int s = e.getDuration() / 20;
                String t = e.isInfinite() ? "inf" : String.format("%d:%02d", s / 60, s % 60);
                c.drawText(mc.textRenderer, n, x + 6, row, 0xFFFFFFFF, false);
                c.drawText(mc.textRenderer, t, x + w - 6 - Draw.tw(t), row, 0xFFB0B0B8, false);
                row += 11;
            }
        }
    }

    static class BetterNear extends Module {
        BetterNear() { super("Better Near", "Игроки рядом (до 50 блоков)", Category.INTERFACE); }
        public void hud(DrawContext c, MinecraftClient mc) {
            List<PlayerEntity> list = others(mc, 50);
            int shown = Math.min(8, list.size());
            int w = 126, h = 18 + Math.max(1, shown) * 13;
            int x = c.getScaledWindowWidth() - w - 6, y = 6;
            Draw.panel(c, x, y, w, h);
            c.drawText(mc.textRenderer, "Better Near", x + 6, y + 5, Theme.color(), true);
            String cnt = String.valueOf(list.size());
            c.drawText(mc.textRenderer, cnt, x + w - 6 - Draw.tw(cnt), y + 5, 0xFFB0B0B8, false);
            if (list.isEmpty()) { c.drawText(mc.textRenderer, "никого рядом", x + 6, y + 19, 0xFF808088, false); return; }
            int row = y + 18;
            for (int i = 0; i < shown; i++) {
                PlayerEntity p = list.get(i);
                PlayerListEntry pe = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (pe != null) PlayerSkinDrawer.draw(c, pe.getSkinTextures(), x + 6, row, 10);
                c.drawText(mc.textRenderer, p.getName().getString(), x + 20, row + 1, 0xFFFFFFFF, true);
                String d = (int) mc.player.distanceTo(p) + "m";
                c.drawText(mc.textRenderer, d, x + w - 6 - Draw.tw(d), row + 1, 0xFFB0B0B8, false);
                row += 13;
            }
        }
    }

    static class ArrayListHud extends Module {
        ArrayListHud() { super("ArrayList", "Список включённых функций", Category.INTERFACE); }
        public void hud(DrawContext c, MinecraftClient mc) {
            List<Module> on = new ArrayList<>();
            for (Module m : ALL) if (m.enabled && m != this && m.cat == Category.VISUALS) on.add(m);
            on.sort(Comparator.comparingInt((Module m) -> Draw.tw(m.name)).reversed());
            int y = c.getScaledWindowHeight() / 2, right = c.getScaledWindowWidth() - 6, i = 0;
            for (Module m : on) {
                int w = Draw.tw(m.name) + 10;
                Draw.rrect(c, right - w, y, w, 12, 3, 0xB0101014);
                c.fill(right - 2, y + 2, right, y + 10, Theme.rainbow(i * 300));
                c.drawText(mc.textRenderer, m.name, right - w + 4, y + 2, i % 2 == 0 ? Theme.color() : 0xFFFFFFFF, true);
                y += 13; i++;
            }
        }
    }
}
