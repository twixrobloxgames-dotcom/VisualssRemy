package dev.remy.visuals.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, desc;
    public final Category cat;
    public final List<Setting> settings = new ArrayList<>();
    public boolean enabled;
    public float anim; // для плавного переключателя в GUI

    protected Module(String name, String desc, Category cat) {
        this.name = name; this.desc = desc; this.cat = cat;
    }

    protected Setting num(String n, double min, double max, double v) {
        Setting s = new Setting(n, min, max, v); settings.add(s); return s;
    }

    protected Setting mode(String n, int idx, String... modes) {
        Setting s = new Setting(n, idx, modes); settings.add(s); return s;
    }

    public void toggle() {
        enabled = !enabled;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!enabled && mc.player != null && mc.world != null) onDisable(mc);
    }

    public void tick(MinecraftClient mc) {}
    public void hud(DrawContext c, MinecraftClient mc) {}
    public void onDisable(MinecraftClient mc) {}
}
