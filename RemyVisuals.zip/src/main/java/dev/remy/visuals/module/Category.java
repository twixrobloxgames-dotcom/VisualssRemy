package dev.remy.visuals.module;

public enum Category {
    VISUALS("Visuals"), INTERFACE("Interface");
    public final String label;
    Category(String l) { label = l; }
}
