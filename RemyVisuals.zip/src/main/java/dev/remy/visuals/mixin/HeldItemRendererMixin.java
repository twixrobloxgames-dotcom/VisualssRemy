package dev.remy.visuals.mixin;

import dev.remy.visuals.module.Modules;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "applySwingOffset", at = @At("HEAD"))
    private void remy$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        Modules.swing.apply(matrices, arm, swingProgress);
    }

    @Inject(method = "applyEquipOffset", at = @At("TAIL"))
    private void remy$viewModel(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
        Modules.viewModel.apply(matrices, arm);
    }
}
